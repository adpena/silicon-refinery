import apple_fm_sdk as fm

async def stream_extract(source_iterable, schema, instructions: str = "Extract data."):
    """
    An asynchronous generator that processes a massive stream of incoming data chunks
    through the local Apple Foundation Model, yielding structured schema objects.

    This function allows you to process gigabytes of data with zero-latency and 
    constant memory overhead, directly interacting with built-in macOS intelligence.

    Args:
        source_iterable (Iterable): An iterable (synchronous or asynchronous) producing 
                                    text or dictionary chunks to process.
        schema: A class decorated with `@apple_fm_sdk.generable()`.
        instructions (str, optional): The system prompt for the Foundation Model.

    Yields:
        schema: The populated structured object.
    
    Example:
        async for review in stream_extract(read_csv_rows("data.csv"), ReviewSchema):
            db.insert(review)
    """
    model = fm.SystemLanguageModel()
    session = fm.LanguageModelSession(model=model, instructions=instructions)
    
    for chunk in source_iterable:
        try:
            result = await session.respond(str(chunk), generating=schema)
            yield result
        except Exception as e:
            print(f"[stream_extract] Failed to process chunk. Error: {e}")
