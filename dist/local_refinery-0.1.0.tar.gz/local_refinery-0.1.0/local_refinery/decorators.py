import functools
import apple_fm_sdk as fm

def local_extract(schema, retries: int = 3):
    """
    A decorator that transforms a Python function into an intelligent, on-device data extractor.
    
    The docstring of the decorated function serves as the system instruction for the LLM. 
    It intercepts the arguments passed to the function, injects them into the local model,
    enforces structured generation according to the provided schema, and returns a fully-validated object.

    Args:
        schema: A class decorated with `@apple_fm_sdk.generable()`. 
                This defines the expected structured output.
        retries (int, optional): The number of times to retry generation if an error occurs. Defaults to 3.

    Returns:
        Callable: The wrapped function returning the requested structured schema.

    Example:
        @fm.generable()
        class Ticket:
            issue: str
            urgency: int
            
        @local_extract(schema=Ticket)
        async def parse_ticket(email: str) -> Ticket:
            \"\"\"Extract issue and urgency from support emails.\"\"\"
            pass
            
        result = await parse_ticket("My screen is broken, need help ASAP!")
        print(result.urgency)
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract instructions from the docstring
            instructions = func.__doc__ or "Extract the following data."
            instructions = instructions.strip()
            
            # Format inputs gracefully
            input_text = " ".join(map(str, args))
            for k, v in kwargs.items():
                input_text += f"\n{k}: {v}"
                
            model = fm.SystemLanguageModel()
            is_available, reason = model.is_available()
            if not is_available:
                raise RuntimeError(f"Foundation Model is not available: {reason}")
                
            session = fm.LanguageModelSession(
                model=model,
                instructions=instructions
            )
            
            for attempt in range(retries):
                try:
                    result = await session.respond(input_text, generating=schema)
                    return result
                except Exception as e:
                    if attempt == retries - 1:
                        raise RuntimeError(f"Failed to generate structured data after {retries} attempts: {e}")
            
        return wrapper
    return decorator
