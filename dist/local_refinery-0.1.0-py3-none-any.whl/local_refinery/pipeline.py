import asyncio
import apple_fm_sdk as fm

class Node:
    """
    Base class for pipeline nodes. 
    Implements the >> operator to construct declarative data processing pipelines.
    """
    def __rshift__(self, other):
        return Pipeline(self, other)

class Pipeline:
    """
    Represents a sequence of connected processing nodes.
    Pipelines use asynchronous generators under the hood for memory-efficient, infinite streams.
    """
    def __init__(self, *nodes):
        self.nodes = nodes

    def __rshift__(self, other):
        """Append another node to the pipeline."""
        return Pipeline(*self.nodes, other)

    async def execute(self):
        """
        Executes the pipeline sequentially.
        
        Returns:
            list: A list containing all the output records collected from the final sink,
                  or None if no nodes were present.
        """
        if not self.nodes:
            return None
        
        # The first node is typically a Source that yields items
        stream = self.nodes[0].process(None)
        
        # Pass the stream through all subsequent processing and sink nodes
        for node in self.nodes[1:]:
            stream = node.process(stream)
            
        # Consume the final stream to trigger execution
        results = []
        async for item in stream:
            results.append(item)
        return results

class Source(Node):
    """
    The origin node of a pipeline. Wraps an iterable and streams its contents asynchronously.
    """
    def __init__(self, iterable):
        """
        Args:
            iterable (Iterable): An iterable of strings or dictionaries to stream.
        """
        self.iterable = iterable

    async def process(self, incoming_stream):
        """Yields items from the configured iterable."""
        for item in self.iterable:
            yield item
            # Relinquish control to the event loop occasionally
            await asyncio.sleep(0)

class Extract(Node):
    """
    An intermediate transformation node that uses the local LLM to extract structured data.
    """
    def __init__(self, schema, instructions: str = "Process and structure this input."):
        """
        Args:
            schema: The `apple_fm_sdk.generable` schema representing the desired output shape.
            instructions (str): The system prompt for the Foundation Model.
        """
        self.schema = schema
        self.instructions = instructions

    async def process(self, incoming_stream):
        """Consumes an incoming stream and yields structured objects extracted by the LLM."""
        model = fm.SystemLanguageModel()
        session = fm.LanguageModelSession(model=model, instructions=self.instructions)
        
        async for item in incoming_stream:
            try:
                # Stringify complex items safely for processing
                payload = str(item)
                result = await session.respond(payload, generating=self.schema)
                yield result
            except Exception as e:
                # In a robust system, we might route errors to a Dead Letter Queue node
                print(f"[Extract Node Warning] Failed to process item. Error: {e}")

class Sink(Node):
    """
    A terminal node that executes a callback for every received item.
    Useful for saving to a database, printing, or passing down another pipeline.
    """
    def __init__(self, callback):
        """
        Args:
            callback (Callable): A synchronous or asynchronous function to execute on each item.
        """
        self.callback = callback

    async def process(self, incoming_stream):
        """Applies the callback to each incoming item and yields it downstream if needed."""
        async for item in incoming_stream:
            # Handle both async and sync callbacks gracefully
            if asyncio.iscoroutinefunction(self.callback):
                await self.callback(item)
            else:
                self.callback(item)
            yield item
